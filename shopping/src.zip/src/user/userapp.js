import { HashRouter, Routes, Route, Link } from "react-router-dom";

const UserModule = () =>{
    return(
        <HashRouter>
            <h1> User App is Working </h1>
        </HashRouter>
    )
}

export default UserModule;