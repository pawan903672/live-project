import { useState, useEffect } from "react";

const MyProduct = () =>{

    return(
        <div className="container mt-4">
            <div className="row mb-4">
                <div className="col-lg-9">
                    <h3 className="text-center text-info"> Product in Inventory </h3>
                </div>
                <div className="col-lg-3">
                    <input type="text" className="form-control" placeholder="Search..."/>
                </div>
            </div>

            <div className="row">
                <div className="col-lg-12 text-center">
                   <p> No Records ! </p>
                </div>
            </div>
        </div>
    )
}

export default MyProduct;